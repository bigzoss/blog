package com.gongji.blog.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gongji.blog.dao.pojo.ArticleTag;

public interface ArticleTagMapper extends BaseMapper<ArticleTag> {
    
}

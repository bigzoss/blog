package com.gongji.blog.vo;

import lombok.Data;

@Data
public class ArticleBodyVo {
    private String content;
}

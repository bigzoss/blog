package com.gongji.blog.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gongji.blog.dao.pojo.Category;

public interface CategoryMapper extends BaseMapper<Category> {
}

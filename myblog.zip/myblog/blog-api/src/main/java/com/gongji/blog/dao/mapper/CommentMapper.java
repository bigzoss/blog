package com.gongji.blog.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gongji.blog.dao.pojo.Comment;

public interface CommentMapper extends BaseMapper<Comment> {
}
